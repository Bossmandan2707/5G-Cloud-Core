#!/usr/bin/env bash
# Step 3 - deploy the 5G core (NRF, AMF, SMF, UPF, UDR, UDM, AUSF, PCF, MongoDB,
# subscriber provisioning, UERANSIM gNB + UE) from the shared pod spec.
#
# Rootful Podman is used on SUSE: the UPF/UE need /dev/net/tun + NET_ADMIN and the pod
# needs the net.ipv4.ip_forward sysctl, all of which are straightforward as root.
set -euo pipefail

[ "$(id -u)" -eq 0 ] || { echo "run as root (sudo $0)"; exit 1; }

HERE="$(cd "$(dirname "$0")" && pwd)"
SPEC="${SPEC:-$HERE/../open5gs-pod.yaml}"
[ -f "$SPEC" ] || { echo "pod spec not found: $SPEC"; exit 1; }

echo "==> Pre-flight"
for m in sctp tun; do lsmod | grep -q "^$m" || { echo "kernel module $m not loaded - run 00-bootstrap-os.sh"; exit 1; }; done
echo "ip_forward=$(cat /proc/sys/net/ipv4/ip_forward)"
FREE_MB=$(awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo)
echo "available memory: ${FREE_MB} MiB (the lab needs roughly 1 GiB)"

echo "==> Deploying $SPEC"
podman kube play --replace "$SPEC"

echo "==> Waiting for the staggered startup (gNB 20s, UE 40s)"
sleep 75

echo "==> Containers"
podman ps --filter pod=open5gs --format "table {{.Names}}\t{{.Status}}"

echo "==> Verifying"
"$HERE/99-verify.sh" podman
