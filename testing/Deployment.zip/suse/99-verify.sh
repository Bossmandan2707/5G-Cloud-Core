#!/usr/bin/env bash
# Verify the lab. Usage:
#   ./99-verify.sh podman              # Podman deployment (run as root on SUSE; rootless works on the Mac)
#   ./99-verify.sh k8s [namespace]     # k3s/Kubernetes deployment (default namespace: open5gs)
set -uo pipefail

MODE="${1:-podman}"
NS="${2:-open5gs}"

logs() { # logs <container>
  case "$MODE" in
    podman) podman logs "open5gs-$1" 2>&1 ;;
    k8s)    kubectl -n "$NS" logs open5gs -c "$1" 2>&1 ;;
    *) echo "unknown mode $MODE" >&2; exit 2 ;;
  esac
}
run() { # run <container> <shell command>
  local c="$1"; shift
  case "$MODE" in
    podman) podman exec "open5gs-$c" sh -c "$*" 2>&1 ;;
    k8s)    kubectl -n "$NS" exec open5gs -c "$c" -- sh -c "$*" 2>&1 ;;
  esac
}

FAIL=0
check() { # check "<label>" "<shell expression evaluated here>"
  if eval "$2" >/dev/null 2>&1; then echo "PASS  $1"; else echo "FAIL  $1"; FAIL=1; fi
}

check "NRF has >= 6 NF registrations" '[ "$(logs nrf | grep -c "NF registered")" -ge 6 ]'
check "N4: SMF<->UPF PFCP associated"  'logs smf | grep -q "PFCP associated"'
check "N2: gNB NG Setup successful"    'logs gnb | grep -q "NG Setup procedure is successful"'
check "UE registration successful"     'logs ue  | grep -q "Initial Registration is successful"'
check "PDU session established"        'logs ue  | grep -q "PDU Session establishment is successful"'

echo
echo "UE tunnel : $(run ue 'ip -br addr show uesimtun0' | head -n1)"
echo "UPF ogstun: $(run upf 'ip -br addr show ogstun' | head -n1)"
echo "ip_forward: $(run upf 'cat /proc/sys/net/ipv4/ip_forward')"

echo
echo "User-plane ping (UE -> internet via GTP-U/UPF/NAT):"
if run ue 'ping -c 3 -W 3 -I uesimtun0 8.8.8.8'; then
  echo "PASS  user plane"
else
  echo "FAIL  user plane (known issue with the single-namespace layout - see README.txt)"
fi

exit $FAIL
